"""initial db

Revision ID: 161e7fa5a27f
Revises: 
Create Date: 2024-09-12 15:01:54.067131

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '161e7fa5a27f'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
