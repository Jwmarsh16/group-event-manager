import React from 'react'

const Groups = () => {
  return (
    <div>
        <h1>Groups</h1>
    </div>
  )
}

export default Groups