import React from 'react';

const Goodbye = () => {
  return (
    <div>
      <h2>Goodbye!</h2>
      <p>Your profile has been successfully deleted.</p>
    </div>
  );
};

export default Goodbye;
